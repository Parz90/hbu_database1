/* ---------------------------------------------------------------------- */
/* Script generated with: DeZign for Databases v6.3.3                     */
/* Target DBMS:           MS SQL Server 2008                              */
/* Project file:          HRS.dez                                         */
/* Project name:                                                          */
/* Author:                                                                */
/* Script type:           Database creation script                        */
/* Created on:            2011-11-15 08:57                                */
/* ---------------------------------------------------------------------- */


/* ---------------------------------------------------------------------- */
/* Tables                                                                 */
/* ---------------------------------------------------------------------- */

/* ---------------------------------------------------------------------- */
/* Add table "HOTELFORM"                                                  */
/* ---------------------------------------------------------------------- */

CREATE TABLE [HOTELFORM] (
    [HF_ID] INTEGER IDENTITY(0,1) NOT NULL,
    [HF_BEZ] VARCHAR(100),
    CONSTRAINT [PK_HOTELFORM] PRIMARY KEY ([HF_ID])
)
GO


/* ---------------------------------------------------------------------- */
/* Add table "ZIMMER_EINRICHTUNG"                                         */
/* ---------------------------------------------------------------------- */

CREATE TABLE [ZIMMER_EINRICHTUNG] (
    [ZE_ID] INTEGER IDENTITY(0,1) NOT NULL,
    [ZE_BEZ] VARCHAR(100),
    CONSTRAINT [PK_ZIMMER_EINRICHTUNG] PRIMARY KEY ([ZE_ID])
)
GO


/* ---------------------------------------------------------------------- */
/* Add table "GAST"                                                       */
/* ---------------------------------------------------------------------- */

CREATE TABLE [GAST] (
    [GA_ID] INTEGER IDENTITY(0,1) NOT NULL,
    [GA_VORNAME] VARCHAR(50),
    [GA_NAME] VARCHAR(50),
    [GA_TELNR] VARCHAR(25),
    [GA_MOBILE] VARCHAR(25),
    [GA_ADRESSE] VARCHAR(100),
    [GA_EMAIL] VARCHAR(100),
    CONSTRAINT [PK_GAST] PRIMARY KEY ([GA_ID])
)
GO


/* ---------------------------------------------------------------------- */
/* Add table "PREISKLASSEN"                                               */
/* ---------------------------------------------------------------------- */

CREATE TABLE [PREISKLASSEN] (
    [PK_ID] INTEGER IDENTITY(0,1) NOT NULL,
    [PK_BEZ] VARCHAR(40),
    CONSTRAINT [PK_PREISKLASSEN] PRIMARY KEY ([PK_ID])
)
GO


/* ---------------------------------------------------------------------- */
/* Add table "KATEGORIE"                                                  */
/* ---------------------------------------------------------------------- */

CREATE TABLE [KATEGORIE] (
    [KA_ID] INTEGER IDENTITY(0,1) NOT NULL,
    [KA_STERNE] INTEGER,
    [KA_BEZ] VARCHAR(40),
    CONSTRAINT [PK_KATEGORIE] PRIMARY KEY ([KA_ID])
)
GO


/* ---------------------------------------------------------------------- */
/* Add table "HOTEL_EINRICHTUNG"                                          */
/* ---------------------------------------------------------------------- */

CREATE TABLE [HOTEL_EINRICHTUNG] (
    [HE_ID] INTEGER IDENTITY(0,1) NOT NULL,
    [HE_BEZ] VARCHAR(40),
    CONSTRAINT [PK_HOTEL_EINRICHTUNG] PRIMARY KEY ([HE_ID])
)
GO


/* ---------------------------------------------------------------------- */
/* Add table "ORT"                                                        */
/* ---------------------------------------------------------------------- */

CREATE TABLE [ORT] (
    [ORT_ID] INTEGER IDENTITY(0,1) NOT NULL,
    [ORT_PLZ] VARCHAR(10),
    [ORT_BEZ] VARCHAR(100),
    [ORT_TELNRVK] VARCHAR(25),
    CONSTRAINT [PK_ORT] PRIMARY KEY ([ORT_ID])
)
GO


/* ---------------------------------------------------------------------- */
/* Add table "HOTEL"                                                      */
/* ---------------------------------------------------------------------- */

CREATE TABLE [HOTEL] (
    [HO_ID] INTEGER IDENTITY(0,1) NOT NULL,
    [KA_ID] INTEGER NOT NULL,
    [HF_ID] INTEGER NOT NULL,
    [ORT_ID] INTEGER NOT NULL,
    [HO_NAME] VARCHAR(100),
    [HO_TELEFON] VARCHAR(25),
    [HO_ADRESSE] VARCHAR(100),
    CONSTRAINT [PK_HOTEL] PRIMARY KEY ([HO_ID])
)
GO


/* ---------------------------------------------------------------------- */
/* Add table "ZIMMER"                                                     */
/* ---------------------------------------------------------------------- */

CREATE TABLE [ZIMMER] (
    [HO_ID] INTEGER NOT NULL,
    [ZI_ID] INTEGER IDENTITY(0,1) NOT NULL,
    [PK_ID] INTEGER NOT NULL,
    [ZI_BEZEICHNUNG] VARCHAR(40),
    [ZI_PREIS] NUMERIC(5,2),
    [ZI_GROESSE] INTEGER,
    [ZI_BETTEN] INTEGER,
    CONSTRAINT [PK_ZIMMER] PRIMARY KEY ([HO_ID], [ZI_ID])
)
GO


/* ---------------------------------------------------------------------- */
/* Add table "RESERVATION"                                                */
/* ---------------------------------------------------------------------- */

CREATE TABLE [RESERVATION] (
    [RE_ID] INTEGER IDENTITY(0,1) NOT NULL,
    [HO_ID] INTEGER NOT NULL,
    [ZI_ID] INTEGER NOT NULL,
    [GA_ID] INTEGER NOT NULL,
    [RE_VON] DATE,
    [RE_BIS] DATE,
    CONSTRAINT [PK_RESERVATION] PRIMARY KEY ([RE_ID])
)
GO


/* ---------------------------------------------------------------------- */
/* Add table "HZ_EINRICHTUNG"                                             */
/* ---------------------------------------------------------------------- */

CREATE TABLE [HZ_EINRICHTUNG] (
    [ZI_ID] INTEGER NOT NULL,
    [HO_ID] INTEGER NOT NULL,
    [ZE_ID] INTEGER NOT NULL,
    [ZE_ANZAHL] INTEGER,
    CONSTRAINT [PK_HZ_EINRICHTUNG] PRIMARY KEY ([ZI_ID], [HO_ID], [ZE_ID])
)
GO


/* ---------------------------------------------------------------------- */
/* Add table "HE_EINRICHTUNG"                                             */
/* ---------------------------------------------------------------------- */

CREATE TABLE [HE_EINRICHTUNG] (
    [HO_ID] INTEGER NOT NULL,
    [HE_ID] INTEGER NOT NULL,
    [HE_ANZAHL] INTEGER,
    CONSTRAINT [PK_HE_EINRICHTUNG] PRIMARY KEY ([HO_ID], [HE_ID])
)
GO


/* ---------------------------------------------------------------------- */
/* Foreign key constraints                                                */
/* ---------------------------------------------------------------------- */

ALTER TABLE [HOTEL] ADD CONSTRAINT [KATEGORIE_HOTEL] 
    FOREIGN KEY ([KA_ID]) REFERENCES [KATEGORIE] ([KA_ID])
GO


ALTER TABLE [HOTEL] ADD CONSTRAINT [HOTELFORM_HOTEL] 
    FOREIGN KEY ([HF_ID]) REFERENCES [HOTELFORM] ([HF_ID])
GO


ALTER TABLE [HOTEL] ADD CONSTRAINT [ORT_HOTEL] 
    FOREIGN KEY ([ORT_ID]) REFERENCES [ORT] ([ORT_ID])
GO


ALTER TABLE [ZIMMER] ADD CONSTRAINT [PREISKLASSEN_ZIMMER] 
    FOREIGN KEY ([PK_ID]) REFERENCES [PREISKLASSEN] ([PK_ID])
GO


ALTER TABLE [ZIMMER] ADD CONSTRAINT [HOTEL_ZIMMER] 
    FOREIGN KEY ([HO_ID]) REFERENCES [HOTEL] ([HO_ID])
GO


ALTER TABLE [RESERVATION] ADD CONSTRAINT [GAST_RESERVATION] 
    FOREIGN KEY ([GA_ID]) REFERENCES [GAST] ([GA_ID])
GO


ALTER TABLE [RESERVATION] ADD CONSTRAINT [ZIMMER_RESERVATION] 
    FOREIGN KEY ([HO_ID], [ZI_ID]) REFERENCES [ZIMMER] ([HO_ID],[ZI_ID])
GO


ALTER TABLE [HZ_EINRICHTUNG] ADD CONSTRAINT [ZIMMER_HZ_EINRICHTUNG] 
    FOREIGN KEY ([ZI_ID], [HO_ID]) REFERENCES [ZIMMER] ([ZI_ID],[HO_ID]) ON DELETE CASCADE ON UPDATE CASCADE
GO


ALTER TABLE [HZ_EINRICHTUNG] ADD CONSTRAINT [ZIMMER_EINRICHTUNG_HZ_EINRICHTUNG] 
    FOREIGN KEY ([ZE_ID]) REFERENCES [ZIMMER_EINRICHTUNG] ([ZE_ID])
GO


ALTER TABLE [HE_EINRICHTUNG] ADD CONSTRAINT [HOTEL_HE_EINRICHTUNG] 
    FOREIGN KEY ([HO_ID]) REFERENCES [HOTEL] ([HO_ID]) ON DELETE CASCADE ON UPDATE CASCADE
GO


ALTER TABLE [HE_EINRICHTUNG] ADD CONSTRAINT [HOTEL_EINRICHTUNG_HE_EINRICHTUNG] 
    FOREIGN KEY ([HE_ID]) REFERENCES [HOTEL_EINRICHTUNG] ([HE_ID])
GO

